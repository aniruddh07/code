package com.stepDefination;

import org.openqa.selenium.WebDriver;

import com.pages.Locators;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class StepDefination {
 WebDriver driver = Hook.driver;
	
	@Given("^User is on home screen$")
	public void user_is_on_home_screen() throws Throwable {
     System.out.println("Üser is on home scree");
	}

	@Then("^Validation complete page$")
	public void validation_complete_page() throws Throwable {
        Locators ls = new Locators(driver);
        ls.validateButtonAndLabel(); 
	}

	@Then("^User enter \"([^\"]*)\"$")
	public void user_enter(String arg1) throws Throwable {
		 Locators ls = new Locators(driver);
		 ls.enterCity(arg1);
	}

	@Then("^User click on search button$")
	public void user_click_on_search_button() throws Throwable {
		 Locators ls = new Locators(driver);
		 ls.clickSearch();
	}
	
	@Then("^User validate not found$")
	public void user_validate_not_found() throws Throwable {
		Locators ls = new Locators(driver);
		ls.validateNotFoundText();
	}
	
	@Then("^validate city name$")
	public void validate_city_name() throws Throwable {
		Locators ls = new Locators(driver);
		ls.validateCityNameAndTemprature(); 
	}
	
	
	@Given("^User hit base url and get response$")
	public void user_hit_base_url_and_get_response() throws Throwable {
		RestMethod rm = new RestMethod();
		rm.weatherResponseBody();
	}

	@Then("^User validate status code \"([^\"]*)\"$")
	public void user_validate_status_code(int arg1) throws Throwable {
		RestMethod rm = new RestMethod();
		rm.validateStatusCode(arg1);
	}

	@Then("^User validate city \"([^\"]*)\"$")
	public void user_validate_city(String arg1) throws Throwable {
		RestMethod rm = new RestMethod();
		rm.validateName(arg1);  
	}




}

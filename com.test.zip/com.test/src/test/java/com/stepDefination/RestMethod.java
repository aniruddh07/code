package com.stepDefination;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ResponseBody;
import com.jayway.restassured.specification.RequestSpecification;

public class RestMethod {

	public static JsonPath jsonPath;
	public static Response response;
	public static ResponseBody body;

public void weatherResponseBody()
{
 RestAssured.baseURI = "http://samples.openweathermap.org/data/2.5";
 RequestSpecification httpRequest = RestAssured.given();
 response = httpRequest.get("/weather?q=London,uk&appid=b6907d289e10d714a6e88b30761fae22");
 body = response.getBody();
 System.out.println("Response Body is: " + body.asString());
}

public void validateStatusCode(int code) {
		try {
			assertEquals(code,response.getStatusCode() );
		}catch (Exception e) {
			System.out.println("Execution fail due to : " +e);
		}
	
}

public void validateName(String name) {
	jsonPath = response.jsonPath();
	try {
		assertEquals(name,jsonPath.getString("name"));
	}catch (Exception e) {
		System.out.println("Execution fail due to : " +e);
	}
}
}

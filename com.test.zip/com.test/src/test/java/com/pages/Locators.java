package com.pages;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class Locators {
WebDriver driver;
String workingDir = System.getProperty("user.dir");
public static String Price;
	
	public Locators(WebDriver driver) 
	{           
	   this.driver = driver; 
	   PageFactory.initElements(driver, this);
	}
	
	
///////////////////////////////////////// Locators ///////////////////////////////////////////////	
	@FindBy(xpath="//*[@id='undefined-sticky-wrapper']/div/div/div/div[2]/ul/li[3]/a") public WebElement text_Weather;
	@FindBy(xpath="//*[@id='undefined-sticky-wrapper']/div/div/div/div[2]/ul/li[4]/a") public WebElement text_Map;
	@FindBy(xpath="//*[text()='Guide']") public WebElement text_Guide;
	@FindBy(xpath="//*[text()='API']") public WebElement text_API;
	@FindBy(xpath="//*[text()='Price']") public WebElement text_Price;
	@FindBy(xpath="//*[text()='Partners']") public WebElement text_Partners;
	@FindBy(xpath="//*[text()='Stations']") public WebElement text_Stations;
	@FindBy(xpath="//*[text()='Widgets']") public WebElement text_Widgets;
	@FindBy(xpath="//*[@id='undefined-sticky-wrapper']/div/div/div/div[2]/ul/li[11]/a") public WebElement text_Blogs;
	@FindBy(xpath="//*[@class='form-control border-color col-sm-12']") public WebElement tf_Search;
	@FindBy(xpath="//*[@id='searchform']/button") public WebElement btn_Search;
	@FindBy(xpath="//*[@id='tab-main']") public WebElement tab_Main;
	@FindBy(xpath="//*[@id='tab-daily']") public WebElement tab_Daily;
	@FindBy(xpath="//*[@id='tab-hourly']") public WebElement tab_Hourly;
	@FindBy(xpath="//*[@id='tab-chart']") public WebElement tab_Chart;
	@FindBy(xpath="//*[@id='tab-map']") public WebElement tab_Map;
	@FindBy(xpath="//*[@id='forecast_list_ul']/div/text()") public WebElement text_NotFound;
	@FindBy(xpath="/html/body/main/div[5]/div/div/h3") public WebElement text_Search;
	@FindBy(xpath="//*[@id='metric']") public WebElement btn_C;
	@FindBy(xpath="//*[@id='imperial']") public WebElement btn_F;
	@FindBy(xpath="//*[text()='More weather in your city']") public WebElement btn_More;
	@FindBy(xpath="//*[text()='Try it right now']") public WebElement btn_Try;
	@FindBy(xpath="//*[text()='About Dashboard']") public WebElement btn_About;
	@FindBy(xpath="//*[text()='Go to agromonitoring.com']") public WebElement btn_Go;
	@FindBy(xpath="//*[text()='Read more']") public WebElement btn_ReadMore;
	@FindBy(xpath="//*[text()='View solutions']") public WebElement btn_View;
	@FindBy(xpath="//*[text()='Try Free APIs']") public WebElement btn_TryFree;
	@FindBy(xpath="//*[text()='Connect']") public WebElement btn_Connect;
	@FindBy(xpath="//*[text()='Weather in your city']") public WebElement text_WeatherInYourCity;
	@FindBy(xpath="//*[text()='Weather APIs']") public WebElement text_WeatherAPI;
	@FindBy(xpath="//*[text()='Map layers']") public WebElement text_MapLayers;
	@FindBy(xpath="//*[text()='How to subscribe']") public WebElement text_HowToSub;
	@FindBy(xpath="//*[text()='Weather station network']") public WebElement text_Station;
	@FindBy(xpath="//*[text()='About']") public WebElement text_About;
	@FindBy(xpath="//*[text()='Go Social']") public WebElement text_GoSocial;
	@FindBy(xpath="//*[@id='forecast_list_ul']/table/tbody/tr/td[2]/b[1]/a") public WebElement cityName;
	@FindBy(xpath="//*[@id='forecast_list_ul']/table/tbody/tr/td[2]/p[1]/span") public WebElement temp;

	

///////////////////////////////////////// Action Methods ///////////////////////////////////////////////		
	public void validateButtonAndLabel() {
		try {
		assertTrue("Weather tab is present", text_Weather.isDisplayed());
		assertTrue("Map tab is present", text_Map.isDisplayed());
		assertTrue("Guide tab is present", text_Guide.isDisplayed());
		assertTrue("API tab is present", text_API.isDisplayed());
		assertTrue("Price tab is present", text_Price.isDisplayed());
		assertTrue("Patners tab is present", text_Partners.isDisplayed());
		assertTrue("Stations", text_Stations.isDisplayed());
		assertTrue("Widgets tab is present", text_Widgets.isDisplayed());
		assertTrue("Blogs tab is present", text_Blogs.isDisplayed());
		assertTrue("Search text field is present", tf_Search.isDisplayed());
		assertTrue("Search button is present", btn_Search.isDisplayed());
		assertTrue("Under map main tab is present", tab_Main.isDisplayed());
		assertTrue("Under map daily tab is present", tab_Daily.isDisplayed());
		assertTrue("Under map hourly tab is present", tab_Hourly.isDisplayed());
		assertTrue("Under map Map tab is present", tab_Map.isDisplayed());
		assertTrue("Under map chart tab  is present", tab_Chart.isDisplayed());
		assertTrue("C button present", btn_C.isDisplayed());
		assertTrue("F button is present", btn_F.isDisplayed());
		assertTrue("More Option", btn_More.isDisplayed());
		assertTrue("Button Try", btn_Try.isDisplayed());
		assertTrue("Button About", btn_About.isDisplayed());
		assertTrue("Go button", btn_Go.isDisplayed());
		assertTrue("Read More button", btn_ReadMore.isDisplayed());
		assertTrue("View button", btn_View.isDisplayed());
		assertTrue("Button try free", btn_TryFree.isDisplayed());
		assertTrue("Connect", btn_Connect.isDisplayed());
		assertTrue("Text weather is your city", text_WeatherInYourCity.isDisplayed());
		assertTrue("Text weather API", text_WeatherAPI.isDisplayed());
		assertTrue("Text Map layers", text_MapLayers.isDisplayed());
		assertTrue("Text how to sub", text_HowToSub.isDisplayed());
		assertTrue("Station text", text_Station.isDisplayed());
		assertTrue("Text about", text_About.isDisplayed());
		assertTrue("Text social", text_GoSocial.isDisplayed());
		}catch (Exception e) {
			System.out.println("Execution fail due to : " +e);
		}
	}
	
	public void enterCity(String name) {
		try {
	      tf_Search.sendKeys(name);
		}catch (Exception e) {
			System.out.println("Execution fail due to : " +e);
		}
	}
	
	public void clickSearch() {
		try {
	      btn_Search.click();
		}catch (Exception e) {
			System.out.println("Execution fail due to : " +e);
		}
	}
	
	public void validateNotFoundText() {
		try {
			assertTrue("Not found text", text_NotFound.isDisplayed());
		}catch (Exception e) {
			System.out.println("Execution fail due to : " +e);
		}
	}
	
	public void validateCityNameAndTemprature() {
		try {
			assertEquals("London, GB", cityName.getText());
			assertTrue("Temperature", temp.isDisplayed());
		}catch (Exception e) {
			System.out.println("Execution fail due to : " +e);
		}
	}
	
}
